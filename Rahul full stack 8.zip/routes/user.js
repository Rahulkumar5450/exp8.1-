import express from "express";
import { verifyToken, authorizeRoles } from "../middleware/auth.js";

const router = express.Router();

router.get("/user-profile", verifyToken, authorizeRoles("User", "Admin", "Moderator"), (req, res) => {
  res.json({
    message: `Welcome to your profile, ${req.user.user.username}!`,
    user: req.user.user
  });
});

export default router;

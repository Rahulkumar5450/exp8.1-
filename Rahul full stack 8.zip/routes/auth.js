import express from "express";
import jwt from "jsonwebtoken";
import { SECRET } from "../middleware/auth.js";

const router = express.Router();

router.post("/login", (req, res) => {
  const { id, username, password, role } = req.body;
  if (!id || !username || !password || !role) {
    return res.status(400).json({ message: "Missing credentials" });
  }

  const token = jwt.sign({ user: { id, username, role } }, SECRET, { expiresIn: "1h" });
  res.json({ token });
});

export default router;

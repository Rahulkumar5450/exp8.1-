import express from "express";
import bodyParser from "body-parser";
import authRoutes from "./routes/auth.js";
import adminRoutes from "./routes/admin.js";
import moderatorRoutes from "./routes/moderator.js";
import userRoutes from "./routes/user.js";

const app = express();
app.use(bodyParser.json());

app.use("/", authRoutes);
app.use("/", adminRoutes);
app.use("/", moderatorRoutes);
app.use("/", userRoutes);

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
